#
# Mail settings
#

# SMTP server
$sMailServer = "host.domain.loc"
$sMailServerPort = "25"
$sMailUsername = ""
$sMailPassword = ""
$fMailServerSSL = $false

# Sender
$sMailFrom = "administrator@domain.loc"

# Recipients, seperated by ","
$sMailTo = "it@domain.loc"


#
# Disk settings
#

# Minimum diskspace in %
$iDiskspace = 20


#
# Processes
#

# Number of top processes
$iProccesses = 10


#
# System events settings
#

# Display events for the last hours
$iSystemEventLastHours = 25


#
# Applicaton events settings
#

# Display events for the last hours
$iApplicationEventLastHours = 25
